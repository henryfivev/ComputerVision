import cv2
import numpy as np

# 读取图像
image = cv2.imread('lena.jpg', 0)  # 使用灰度模式读取图像

# 定义Roberts算子
roberts_x = np.array([[1, 0], [0, -1]])
roberts_y = np.array([[0, 1], [-1, 0]])

# 对图像进行边缘检测
edges_x = cv2.filter2D(image, -1, roberts_x)
edges_y = cv2.filter2D(image, -1, roberts_y)

# 组合水平和垂直边缘
edges = cv2.add(np.abs(edges_x), np.abs(edges_y))

# 显示原始图像和边缘图像
cv2.imshow('Original Image', image)
cv2.imshow('Roberts Edges', edges)
cv2.imwrite('roberts.jpg', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
