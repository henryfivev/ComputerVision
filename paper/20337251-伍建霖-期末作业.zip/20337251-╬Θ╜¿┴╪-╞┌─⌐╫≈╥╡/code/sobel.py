import cv2

# 读取图像
image = cv2.imread('lena.jpg', 0)  # 使用灰度模式读取图像

# 对图像进行边缘检测
edges_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
edges_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)

# 取绝对值并将结果转换为8位图像
edges_x = cv2.convertScaleAbs(edges_x)
edges_y = cv2.convertScaleAbs(edges_y)

# 组合水平和垂直边缘
edges = cv2.addWeighted(edges_x, 0.5, edges_y, 0.5, 0)

# 显示原始图像和边缘图像
cv2.imshow('Original Image', image)
cv2.imshow('Sobel Edges', edges)
cv2.imwrite('sobel.jpg', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
