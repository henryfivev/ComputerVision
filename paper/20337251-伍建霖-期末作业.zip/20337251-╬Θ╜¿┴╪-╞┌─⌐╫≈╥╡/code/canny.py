import cv2

# 读取图像
image = cv2.imread('lena.jpg', 0)  # 使用灰度模式读取图像

# 对图像进行边缘检测
edges = cv2.Canny(image, threshold1=100, threshold2=200)  # 根据需要调整阈值

# 显示原始图像和边缘图像
cv2.imshow('Original Image', image)
cv2.imshow('Canny Edges', edges)
cv2.imwrite("canny.jpg", edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
