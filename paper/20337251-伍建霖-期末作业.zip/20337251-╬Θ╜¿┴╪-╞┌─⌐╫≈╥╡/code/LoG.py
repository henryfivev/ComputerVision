import cv2

# 读取图像
image = cv2.imread('lena.jpg', 0)  # 使用灰度模式读取图像

# 高斯平滑
image_blur = cv2.GaussianBlur(image, (3, 3), 0)

# 使用Laplacian算子计算图像的二阶导数
laplacian = cv2.Laplacian(image_blur, cv2.CV_64F)

# 取绝对值并将结果转换为8位图像
edges = cv2.convertScaleAbs(laplacian)

# 显示原始图像和边缘图像
cv2.imshow('Original Image', image)
cv2.imshow('LoG Edges', edges)
cv2.imwrite("LoG.jpg", edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
